#!/usr/bin/env python3

import argparse
import logging
import os
import subprocess
import sys
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("zephyr-xml-launcher")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Launch the Feature to JUnit XML converter (Python runner)."
    )
    parser.add_argument("--feature", help="Path to a specific .feature file")
    parser.add_argument(
        "--feature-dir",
        help="Directory to search for .feature files",
        default="features",
    )
    parser.add_argument(
        "--config", default="user_config.toml", help="Path to user config TOML"
    )
    parser.add_argument(
        "--zephyr-config",
        default="zephyr_config.toml",
        help="Path to Zephyr config TOML",
    )
    parser.add_argument(
        "--output-dir", default="output", help="Where to place XML outputs"
    )
    return parser.parse_args()


def read_push_flag(user_config_path):
    if not Path(user_config_path).is_file():
        logger.warning(f"⚠️ user_config.toml not found: {user_config_path}")
        return False
    with open(user_config_path, "r") as f:
        for line in f:
            if "upload" in line.lower() and "=" in line:
                key, value = line.strip().split("=", 1)
                return "true" in value.strip().lower()
    return False


def build_command(
    jar, feature_path, output_path, config_path, zephyr_config, push_enabled
):
    cmd = [
        "java",
        "-jar",
        str(jar),
        "--feature",
        str(feature_path),
        "--config",
        str(config_path),
        "--output",
        str(output_path),
    ]
    if push_enabled:
        cmd.extend(["--zephyr-config", str(zephyr_config)])
    return cmd


def main():
    logger.info("🚀 Running Python version of launchFeatureToJUnit script...")

    args = parse_args()

    # Find the JAR file
    jar_path = Path("featurefileToXML.jar")
    if not jar_path.is_file():
        jar_path = Path("target/featurefileToXML.jar")
        if not jar_path.is_file():
            logger.error(
                "❌ Could not find featurefileToXML.jar or target/featurefileToXML.jar"
            )
            sys.exit(1)

    # Determine if Zephyr push is enabled
    push_enabled = read_push_flag(args.config)
    if push_enabled:
        logger.info("📤 Zephyr upload is ENABLED.")
        if not Path(args.zephyr_config).is_file():
            logger.error(f"❌ Zephyr config file not found: {args.zephyr_config}")
            sys.exit(1)
    else:
        logger.info("📤 Zephyr upload is DISABLED.")

    # Ensure output directory exists
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Single feature file mode
    if args.feature:
        feature_path = Path(args.feature)
        if not feature_path.is_file():
            logger.error(f"❌ Feature file not found: {feature_path}")
            sys.exit(1)
        output_path = output_dir / f"{feature_path.stem}_junit_output.xml"
        logger.info(f"🔄 Converting {feature_path} → {output_path}")
        subprocess.run(
            build_command(
                jar_path,
                feature_path,
                output_path,
                args.config,
                args.zephyr_config,
                push_enabled,
            ),
            check=True,
        )
    else:
        # Recursive conversion mode
        feature_dir = Path(args.feature_dir)
        if not feature_dir.is_dir():
            logger.error(f"❌ Feature directory not found: {feature_dir}")
            sys.exit(1)
        feature_files = list(feature_dir.rglob("*.feature"))
        if not feature_files:
            logger.warning("⚠️ No .feature files found.")
            sys.exit(0)
        logger.info(f"📁 Recursively converting all .feature files in {feature_dir}/")
        for feature_file in feature_files:
            output_path = output_dir / f"{feature_file.stem}_junit_output.xml"
            logger.info(f"🔄 {feature_file} → {output_path}")
            subprocess.run(
                build_command(
                    jar_path,
                    feature_file,
                    output_path,
                    args.config,
                    args.zephyr_config,
                    push_enabled,
                ),
                check=True,
            )

    logger.info("✅ Done.")


if __name__ == "__main__":
    main()
