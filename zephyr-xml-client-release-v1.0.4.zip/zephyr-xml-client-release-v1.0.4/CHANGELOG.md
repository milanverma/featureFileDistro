# Changelog

## [v1.0.4] - 2025-11-30
### Added
- python runner

## [v1.0.3] - 2025-11-30
### Added
- screen output confirming whether cert check is enabled or disabled

## [v1.0.2] - 2025-09-30
### Added
- no certifcation check, with flag in zephy TOML file

## [v1.0.1] - 2025-06-05
### Added
- CLI argument `--zephyr-config` for flexibility
- Better error handling for missing config blocks

### Changed
- Refactored upload logic to centralise TOML parsing
- Client delivery now includes MIT license

---

## [v1.0.0] - 2025-06-01
- Initial release
- Feature-to-JUnit XML conversion
- Upload support to Zephyr Enterprise
