FEATUREFILE TO JUNIT XML CONVERTER
=================================

A lightweight CLI tool that converts Gherkin .feature files into JUnit-compatible XML, suitable for CI pipelines and test management systems.

The tool optionally uploads generated results to Zephyr Enterprise using its REST API when configured.


OVERVIEW
--------

This utility is designed for teams using Gherkin-based BDD who want:

- Predictable, readable JUnit XML output
- Fine-grained control over tags and scenarios
- Seamless automation test case creation in Zephyr Enterprise
- Minimal setup with clear, debuggable configuration


KEY FEATURES
------------

- Convert .feature files (Gherkin) into JUnit XML
- Supports both Scenario and Scenario Outline (with Examples)
- Descriptive test case naming derived from scenario and example names
- Tag handling:
  - Include tags from feature, scenario, outline, and examples
  - Exclude specific tags from output
  - Exclude entire scenarios from upload based on scenario-level tags
- Optional injection of a global tag into all test cases
- Optional timestamping of test cases
- Automatic upload to Zephyr Enterprise
- Automatic resolution of:
  - Project ID
  - Release ID
  - Test Repository folder (TCR)
- Supports both Python (.py) and Shell (.sh) launchers
- Clear debug and decision logging


REQUIREMENTS
------------

- Java 8 or later (to run the JAR)
- Python 3 (recommended runner)
- Bash (optional, for shell runner)


USAGE
-----

RECOMMENDED FIRST RUN (PYTHON RUNNER)

The Python launcher is the recommended entry point, as it provides clearer logging and better cross-platform support.

Command:
./launchFeatureToJUnit.py --feature sample.feature --config user_config.toml --zephyr-config zephyr_config.toml


ALTERNATIVE: SHELL RUNNER

Command:
./launchFeatureToJUnit.sh --feature path/to/your.feature --config path/to/user_config.toml --zephyr-config path/to/zephyr_config.toml


OUTPUT LOCATION
---------------

By default, converted JUnit XML files are written to:

output/

You can override this using the --output argument.


CONFIGURATION
-------------

USER_CONFIG.TOML

Controls conversion behaviour, tagging, and scenario filtering.

Example content:

[behavior]
mark_all_passed = true
extra_tag = "automated"
include_timestamp = true
feature_name_as_classname = true
upload = true

[filters]
exclude_tags = ["Zoom", "UI", "allure*", "Day*"]
exclude_scenarios_with_tags = ["setup_feature", "teardown_feature"]


BEHAVIOUR OPTIONS

mark_all_passed
Marks all test cases as passed. If false, keywords such as "fail" or "invalid" simulate failures.

extra_tag
Adds a tag to every test case.

include_timestamp
Adds ISO-8601 timestamps to test case entries.

feature_name_as_classname
Uses the Feature name as the JUnit classname.

upload
Enables Zephyr upload when set to true.


FILTERING OPTIONS

exclude_tags
Removes matching tags from the XML output without skipping the test case. Supports wildcard patterns.

exclude_scenarios_with_tags
Skips entire scenarios from XML generation and upload. Intended for setup or teardown scenarios.


ZEPHYR_CONFIG.TOML
-----------------

Required only when upload is enabled.

Example content:

[zephyr]
base_url = "https://your.zephyr.instance"
auth_token = "your_auth_token_here"
insecure_tls = false

[project]
name = "Your Project Name"

[release]
name = "Release 3.4"

[testRepository]
testRepositoryPath = "Release 3.4 > Automation"


NOTES
-----

- Project and release names must match exactly
- Only one folder level under the release root is currently supported


EXAMPLE CONSOLE OUTPUT
----------------------

Converting sample.feature -> output/sample_junit_output.xml
Loading config from: user_config.toml
Skipping scenario due to excluded scenario tag(s): Setup (should be skipped from upload when configured)
Writing test: Sanity check - plain Scenario is generated and uploaded to Zephyr
Writing test: Successful reversal of buy side in RIB House inter-office trade in LMEsmart - Forward - Dollar
Feature converted to JUnit XML: output/sample_junit_output.xml
Resolved Project 'Ironclad' -> ID 1
Resolved Release 'Release 3.4' -> ID 49
Resolved folder 'Automation' -> TCR ID 8690
Upload successful
Done


KNOWN LIMITATIONS
-----------------

- Only one level of test repository hierarchy is supported under the release root
- Project and release resolution requires exact name matches
- Scenario exclusion is tag-based only


CHANGELOG
---------

See CHANGELOG.md for full version history.


SUPPORT / CONTACT
-----------------

For questions, improvements, or advanced usage:

Dr. Milan Verma
Email: trigenica365@gmail.com


LICENSE
-------

© 2026 Milan Verma

This project is licensed under the MIT License.
See the LICENSE file for details.
