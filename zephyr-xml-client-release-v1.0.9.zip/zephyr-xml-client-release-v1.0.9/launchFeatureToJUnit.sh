#!/bin/bash

set -e

FEATURE=""
CONFIG_FILE="user_config.toml"
ZEPHYR_CONFIG="zephyr_config.toml"
OUTPUT_DIR="output"
OUTPUT=""

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --feature) FEATURE="$2"; shift ;;
        --config) CONFIG_FILE="$2"; shift ;;
        --zephyr-config) ZEPHYR_CONFIG="$2"; shift ;;
        --output) OUTPUT="$2"; shift ;;
        *) echo "❌ Unknown parameter passed: $1"; exit 1 ;;
    esac
    shift
done

# Auto-detect JAR location
if [[ -f "featurefileToXML.jar" ]]; then
  JAR="featurefileToXML.jar"
elif [[ -f "target/featurefileToXML.jar" ]]; then
  JAR="target/featurefileToXML.jar"
else
  echo "❌ Could not find featurefileToXML.jar in current or target/ directory."
  exit 1
fi

# Check jq
if ! command -v jq &> /dev/null; then
  echo "❌ 'jq' is required but not installed. Please install it to proceed."
  exit 1
fi

# Validate config files
if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "❌ user config file not found: $CONFIG_FILE"
  exit 1
fi

# Check push flag
PUSH_TO_ZEPHYR=$(grep -E '^push_to_zephyr\s*=' "$CONFIG_FILE" | sed 's/.*= *//' | tr -d '"')
if [[ "$PUSH_TO_ZEPHYR" == "true" && ! -f "$ZEPHYR_CONFIG" ]]; then
  echo "❌ Zephyr push is enabled, but $ZEPHYR_CONFIG was not found."
  exit 1
fi

# Create output directory if not exists
mkdir -p "$OUTPUT_DIR"

# Convert feature(s)
if [[ -n "$FEATURE" ]]; then
  out="$OUTPUT"
  [[ -z "$out" ]] && out="$OUTPUT_DIR/$(basename "$FEATURE" .feature)_junit_output.xml"

  echo "🔄 Converting $FEATURE → $out"
  java -jar "$JAR" \
    --feature "$FEATURE" \
    --config "$CONFIG_FILE" \
    --zephyr-config "$ZEPHYR_CONFIG" \
    --output "$out"
else
  echo "📁 Converting all .feature files in $FEATURE_DIR/"
  for f in "$FEATURE_DIR"/*.feature; do
    out="$OUTPUT_DIR/$(basename "$f" .feature)_junit_output.xml"
    echo "🔄 $f → $out"
    java -jar "$JAR" \
      --feature "$f" \
      --config "$CONFIG_FILE" \
      --zephyr-config "$ZEPHYR_CONFIG" \
      --output "$out"
  done
fi

echo "✅ Done."
