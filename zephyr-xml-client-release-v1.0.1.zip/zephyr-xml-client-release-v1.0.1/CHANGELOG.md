# Changelog

## [v1.0.1] - 2025-06-05
### Added
- CLI argument `--zephyr-config` for flexibility
- Better error handling for missing config blocks

### Changed
- Refactored upload logic to centralise TOML parsing
- Client delivery now includes MIT license

---

## [v1.0.0] - 2025-06-01
- Initial release
- Feature-to-JUnit XML conversion
- Upload support to Zephyr Enterprise
