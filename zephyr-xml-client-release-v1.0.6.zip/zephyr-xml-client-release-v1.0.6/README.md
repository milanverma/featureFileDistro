# FeatureFile to JUnit XML Converter

A lightweight CLI tool that converts `.feature` files (written in Gherkin) into JUnit-compatible XML for integration with test management tools and CI pipelines.

Supports optional upload to **Zephyr Enterprise** via API when configured.

---

## Features

- Convert `.feature` Gherkin files to JUnit XML
- Add tags, timestamps, and descriptions to test cases
- Push results to **Zephyr Enterprise** using API
- Customizable behavior via `user_config.toml` and `zephyr_config.toml`
- CLI-based shell script (`launchFeatureToJUnit.sh`) to simplify usage

---

## Requirements

- Java 8+ (for running the `.jar`)

---

## Usage

### Basic Conversion

```bash
./launchFeatureToJUnit.sh --feature path/to/your.feature

### Advanced Conversion

/launchFeatureToJUnit.sh \
  --feature path/to/your.feature \
  --config path/to/user_config.toml \
  --zephyr-config path/to/zephyr_config.toml

### Example Output Location
Converted XML files are stored in the output/ directory unless otherwise specified via --output.

### user_config.toml
Controls conversion behavior (e.g., pass/fail simulation, tag injection, timestamps, upload toggle).

[behavior]
mark_all_passed = true
extra_tag = "automated"
include_timestamp = true
feature_name_as_classname = true
upload = true

### zephyr_config.toml
Required only if upload = true. Contains the upload URL, auth token, and job detail fields.

[zephyr]
upload_url = "https://your.zephyr.url/api/upload"
auth_token = "your_auth_token_here"

[automationJobDetail]
automationJobDetailId = 123
jobScheduleDate = 1714560000000
cycleDuration = 3

### Support / Contact
Feel free to reach out with questions, improvements, or to enable advanced features:
Dr. Milan Verma
trigenica365@gmail.com


### License
© 2025 Milan Verma

This project is licensed under the MIT License. See the LICENSE file for details.

### Example run and Output

./launchFeatureToJUnit.sh --feature src/test/resources/sample.feature --config src/main/java/user_config.toml --zephyr-config src/main/java/zephyr_config.toml
🔄 Converting src/test/resources/sample.feature → output/sample_junit_output.xml
📄 Loading config from: src/main/java/user_config.toml
✅ Feature converted to JUnit XML: output/sample_junit_output.xml
📄 Loaded Zephyr config from: /Users/milan.verma/Documents/GitHub/featurefileToXML/src/main/java/zephyr_config.toml
Upload successful. Server response: {  "id" : 501,  "automationJobDetailId" : 187,  "status" : "new",  "jobScheduleDate" : 1749156647285,  "cycleDuration" : 0}
✅ Done.
