# Changelog

## [v1.0.7] - 2025-12-11
### Added
- automatic lookup of projectId and releaseId based on names provided in zephyr_config.toml
- automatic resolution of jobDetailTcrCatalogTreeId using the testRepositoryPath hierarchy (e.g. Release 3.4 > Automation)
- improved logging showing resolved project, release and TCR folder IDs
### Known limitations
- only one level of folder hierarchy under the release root is supported (e.g. Release 3.4 > Automation)
- project and release matching requires exact name matches

## [v1.0.6] - 2025-12-9
### Added
- retested testcase names 
- fixed tag being excluded and 'F' in testcase name bugs
- add all rows for examples as a suffix to testcase names
- improved sanitisation logic to prevent corrupted or non‑ASCII characters appearing in Zephyr test steps


## [v1.0.5] - 2025-12-3
### Added
- tag exclusion logic and toml file customisation
- descriptive test case names from ScenarioOutline + Examples
- avoid corrupted characters in Zephyr

## [v1.0.4] - 2025-11-30
### Added
- python runner

## [v1.0.3] - 2025-11-30
### Added
- screen output confirming whether cert check is enabled or disabled

## [v1.0.2] - 2025-09-30
### Added
- no certifcation check, with flag in zephy TOML file

## [v1.0.1] - 2025-06-05
### Added
- CLI argument `--zephyr-config` for flexibility
- Better error handling for missing config blocks

### Changed
- Refactored upload logic to centralise TOML parsing
- Client delivery now includes MIT license

---

## [v1.0.0] - 2025-06-01
- Initial release
- Feature-to-JUnit XML conversion
- Upload support to Zephyr Enterprise
